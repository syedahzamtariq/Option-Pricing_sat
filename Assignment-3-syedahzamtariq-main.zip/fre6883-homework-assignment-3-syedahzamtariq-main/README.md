[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/LPgrZehc)
# Homework_Assignment_3

Please see our Topic 4 lecture slide #55 for the details of homework assignment #3. You should use a math function for which you could easily verify the integration result, such as

f(x) = x*x*x - x*x + 1, a = 1.0 and b = 2.0.

Please submit your source codes with result pasted in.
