[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/pF4izdII)
# Homework_Assignment_4

Please see our Topic 5 lecture slide #61 for the details of homework assignment #4. The following is a sample of input for your calculation and output from the program:

/* 
    int N = 8;

    double U = 1.15125, D = 0.86862, R = 1.00545;

    double S0 = 106.00, K = 100.00;

    double K1 = 100, K2 = 110;

*/

/*

European call option price = 21.68

European put option price = 11.43

European bull spread option price = 4.72

European bear spread option price = 4.86

*/
