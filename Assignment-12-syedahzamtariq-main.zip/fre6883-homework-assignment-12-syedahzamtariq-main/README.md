[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/PDh4xlJB)
# Homework_Assignment_12

Please refer to Topic 10 Slide # 29 for the details of HW12. The followings are the inputs and outputs for HW12. Your outputs would be different, but should be around the outputs shown here.

Using the same inputs from the source codes for Topic 9. N=3000 and epsilon = 0.001.

Outputs:

Arithmetic Basket Call Price = 2.22962
delta[0] = 0.50609
delta[1] = 0.512323
delta[2] = 0.530237
