[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/dCC_Yw42)
# Homework_Assignment_5

Please see our Topic 5 lecture slide #65 for the details of homework assignment #5. The following is a sample of input for your calculation and output from the program:

/* 

    int N = 8;

    double U = 1.15125, D = 0.86862, R = 1.00545;

    double S0 = 106.00, K1 = 100, K2 = 110;

*/

/*

European double digit option price = 0.26

European strangle option price = 28.39

European butterfly option price = 1.04

*/
