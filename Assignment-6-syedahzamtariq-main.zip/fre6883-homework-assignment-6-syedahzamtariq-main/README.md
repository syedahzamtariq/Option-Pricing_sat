[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/yqE3tbJE)
# Homework_Assignment_6

Please see our Topic 7 Lecture Slide # 53 for the details of the HW6. You could still use the same input we have been using: 

    int N = 8;
    double U = 1.15125, D = 0.86862, R = 1.00545;
    double S0 = 106.00, K = 100.00;

The output should be written to a file. An example of output file is attached in the homework assignment 6 (NYU Brightspace)
