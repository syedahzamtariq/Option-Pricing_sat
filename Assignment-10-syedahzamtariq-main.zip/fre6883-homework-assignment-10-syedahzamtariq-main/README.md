[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/mB7mrzC7)
# Homework_Assignment_10

Please refer to Topic 9 Slide # 36 for the details of HW10. The following are the inputs and outputs for HW10. Your outputs would be different, but around these numbers:

Input:
   double S0=100., r=0.03, sigma=0.2;
   double T=1.0/12.0, K=100.0;
   int m=30;
   long N=30000;
   double epsilon=0.001;

Output:
Asian Call Price = 1.41927
     Pricing Error = 0.0120013
             delta = 0.523105
             gamma = 0.119361
